#!/usr/bin/env bash
set -euo pipefail

echo "Running basic tutorial example..."
echo ""

# Run the basic tutorial example
./qval --config config/tutorial/00_minimal/00_minimal.yaml --samples 1000

echo ""
echo "Done. Output written to: bin/output/tutorial/00_minimal/"
echo "Kernel saved under:      bin/output/tutorial/00_minimal/code/eval.cl"

