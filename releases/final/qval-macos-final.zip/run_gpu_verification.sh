#!/usr/bin/env bash
set -euo pipefail

echo "Running GPU verification tests..."
echo "This will test if the GPU is actually working correctly."
echo ""

# Run GPU verification
./util/run_gpu_verification.sh

echo ""
echo "GPU verification complete."

