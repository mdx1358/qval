#!/usr/bin/env bash
# Expectation: score equals mean(C)=2.5
CSV="$1"
LOG="$2"
score=$(awk -F, 'NR==2{print $3}' "$CSV")
awk -v s="$score" 'BEGIN{v=s+0; if (v>=2.499 && v<=2.501) exit 0; else exit 1}'

