#!/usr/bin/env bash
# Expectation: first data row score equals 3 (min of 10,5,3)
CSV="$1"
LOG="$2"
first_score=$(awk -F, 'NR==2{print $3}' "$CSV")
awk -v s="$first_score" 'BEGIN{v=s+0; if (v>=2.999 && v<=3.001) exit 0; else exit 1}'
