# User configs live here

- Place your personal or project-specific YAMLs under this directory.
- They will run like any other config, and outputs will go under bin/output/<mirror>/...
- You can set per-config out_csv/out_xlsx, but if they point at bin/report they will be redirected to bin/output.

