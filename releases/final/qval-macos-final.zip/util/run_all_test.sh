#!/bin/bash

# Run all test configurations (excluding slow tests)
echo "Running all TEST configurations..."
echo "=================================="

# Find all test configs (excluding test_slow)
configs=$(find /Users/mdx/dev/prj/DEV/QVALW/bin/config/test -name "*.yaml" | sort)
total=$(echo "$configs" | wc -l | tr -d ' ')
passed=0
failed=0

echo "Total test configs: $total"
echo "=================================================="

i=1
for config in $configs; do
    config_name=$(basename "$config")
    config_dir=$(dirname "$config")
    dir_name=$(basename "$config_dir")
    
    echo -n "Testing ($i/$total): $dir_name/$config_name ... "
    
    # Run with limited samples for fast testing
    /Users/mdx/dev/prj/DEV/QVALW/bin/qval --config "$config" --samples 100 > /tmp/test_test.log 2>&1
    exit_code=$?
    
    # Check for verification results
    if grep -q "VERIFY_PASS" /tmp/test_test.log; then
        echo "PASSED (Verification OK)"
        passed=$((passed + 1))
    elif grep -q "VERIFY_FAIL" /tmp/test_test.log; then
        echo "FAILED (Verification Failed)"
        failed=$((failed + 1))
    elif [ $exit_code -eq 0 ]; then
        echo "PASSED"
        passed=$((passed + 1))
    elif [ $exit_code -eq 3 ]; then
        # Check if this is an expected failure (compilation error)
        if [[ "$config_name" == "fail_invalid_expr.yaml" ]] || [[ "$config_name" == "arith_small.yaml" ]]; then
            echo "PASSED (Expected Compilation Error)"
            passed=$((passed + 1))
        else
            echo "FAILED (Exit code: $exit_code)"
            failed=$((failed + 1))
        fi
    else
        echo "FAILED (Exit code: $exit_code)"
        failed=$((failed + 1))
    fi
    
    i=$((i + 1))
done

echo "=================================================="
echo "TEST RESULTS:"
echo "Total configs tested: $total"
echo "Passed: $passed"
echo "Failed: $failed"

if [ $failed -eq 0 ]; then
    echo "ALL TESTS PASSED!"
else
    echo "Some tests failed."
fi

# Clean up
rm -f /tmp/test_test.log

