#!/bin/bash

# Run all tutorial configurations
echo "Running all TUTORIAL configurations..."
echo "======================================"

# Find all tutorial configs
configs=$(find /Users/mdx/dev/prj/DEV/QVALW/bin/config/tutorial -name "*.yaml" | sort)
total=$(echo "$configs" | wc -l | tr -d ' ')
passed=0
failed=0

echo "Total tutorial configs: $total"
echo "=================================================="

i=1
for config in $configs; do
    config_name=$(basename "$config")
    config_dir=$(dirname "$config")
    dir_name=$(basename "$config_dir")
    
    echo -n "Testing ($i/$total): $dir_name/$config_name ... "
    
    # Run with standard samples for tutorials
    /Users/mdx/dev/prj/DEV/QVALW/bin/qval --config "$config" --samples 1000 > /tmp/tutorial_test.log 2>&1
    exit_code=$?
    
    # Check for verification results
    if grep -q "VERIFY_PASS" /tmp/tutorial_test.log; then
        echo "PASSED (Verification OK)"
        passed=$((passed + 1))
    elif [ $exit_code -eq 0 ]; then
        echo "PASSED"
        passed=$((passed + 1))
    else
        echo "FAILED (Exit code: $exit_code)"
        failed=$((failed + 1))
    fi
    
    i=$((i + 1))
done

echo "=================================================="
echo "TUTORIAL TESTS RESULTS:"
echo "Total configs tested: $total"
echo "Passed: $passed"
echo "Failed: $failed"

if [ $failed -eq 0 ]; then
    echo "ALL TUTORIAL TESTS PASSED!"
else
    echo "Some tutorial tests failed."
fi

# Clean up
rm -f /tmp/tutorial_test.log

