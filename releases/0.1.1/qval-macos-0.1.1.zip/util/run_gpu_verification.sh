#!/usr/bin/env bash
set -euo pipefail

echo "Running comprehensive GPU verification tests..."
echo "This will test if the GPU is actually working correctly."
echo ""

# Change to the bin directory to run qval
cd "$(dirname "$0")/.."

# Test 1: Comprehensive GPU test
echo "Test 1: Comprehensive GPU verification (50K samples)"
echo "Testing multiple parameter types and distributions..."
if ./qval --config config/test/gpu_verification/comprehensive_gpu_test.yaml; then
    echo "✓ Comprehensive GPU test PASSED"
else
    echo "✗ Comprehensive GPU test FAILED"
    exit 1
fi

echo ""

# Test 2: GPU stress test
echo "Test 2: GPU stress test (100K samples)"
echo "Testing high sample count and complex math operations..."
if ./qval --config config/test/gpu_verification/gpu_stress_test.yaml; then
    echo "✓ GPU stress test PASSED"
else
    echo "✗ GPU stress test FAILED"
    exit 1
fi

echo ""
echo "GPU verification summary:"
echo "✓ Comprehensive test: Multiple parameter types and distributions"
echo "✓ Stress test: High sample count and complex operations"
echo "✓ All tests completed successfully"
echo ""
echo "Your GPU is working correctly with QVAL!"
