QVAL Quick Start - macOS
========================

What it is:
- QVAL is a GPU-accelerated function evaluator and optimizer.
  It runs thousands to millions of parameter variants in parallel on the GPU and writes results
  and reports. You can provide a simple math expression (expr) or, for advanced cases, a C-like
  expression file (OpenCL code) via expr_file. Prefer a GPU device when available.

Prerequisites:
- macOS with a supported OpenCL driver (Apple Silicon GPUs are supported via cl_to_metal path automatically)
- Unzip the distribution. The `qval` binary and example scripts are in the root directory.

Quick Start:
============

1. List GPU devices:
   ./qval --list-devices

2. Run a basic example:
   ./qval --config config/example/basic/basic.yaml

3. Run the tutorial:
   ./qval --config config/tutorial/00_minimal/00_minimal.yaml

4. Run all tests:
   ./util/run_all_test.sh

5. Run GPU verification:
   ./run_gpu_verification.sh

Quick Sanity Checks:
====================

From the root directory:
```bash
# Basic example with multiple parameters (A, B, C, SPEED)
./run_basic_example.sh

# Comprehensive GPU verification
./run_gpu_verification.sh
```

Comprehensive Testing:
======================

From `util/`:
```bash
# All example configurations
./run_all_example.sh

# All tutorial configurations
./run_all_tutorial.sh

# All test configurations (fast)
./run_all_test.sh

# All slow/GPU load tests
./run_all_slow_test.sh

# All user configurations
./run_all_user.sh

# Comprehensive GPU verification
./run_gpu_verification.sh
```

Manual Commands:
===============

```bash
# Basic example
./qval --config config/example/basic/basic.yaml --samples 1000

# Tutorial example
./qval --config config/tutorial/00_minimal/00_minimal.yaml --samples 1000

# Run with specific device
./qval --config config/example/basic/basic.yaml --device 0:0

# Generate reports
./qval --config config/tutorial/00_minimal/00_minimal.yaml --report txt,md,html --report-out ./report

# Run with custom samples
./qval --config config/example/basic/basic.yaml --samples 50000
```

Where Output Goes:
=================
- output/<config_path>/code/eval.cl — generated OpenCL kernel
- output/<config_path>/<config_name>.csv — results CSV
- output/<config_path>/<config_name>.xlsx — results Excel (if configured)
- report/<config_path>/report.{txt,md,html,json} — human-readable reports

Configuration Structure:
========================
- config/example/ — Example configurations for different use cases
- config/tutorial/ — Step-by-step tutorial configurations
- config/test/ — Test configurations (fast execution)
- config/test_slow/ — Slow/GPU load test configurations
- config/user/ — User-defined configurations (create your own here)

Documentation:
==============
- doc/qval_manual.pdf — Complete documentation (User Manual + Advanced Features + Built-ins Tutorial)

Notes:
======
- Apple Silicon (M1/M2) GPUs are automatically supported via Metal backend
- CSV/XLSX output paths are configured in each YAML file
- Use --quiet to reduce console output, --verbose for OpenCL details
- GPU acceleration is automatic when available
- See doc/qval_manual.pdf for complete documentation

Troubleshooting:
===============
- If GPU not detected: Check System Preferences > Software Update
- If permission denied: chmod +x qval util/*.sh
- If paths not found: Ensure you're running from the root directory
- For detailed help: ./qval --help

Performance Tips:
================
- Use --samples 10000+ for meaningful GPU acceleration
- Apple Silicon GPUs provide excellent performance for optimization tasks
- Monitor Activity Monitor for GPU usage during computation

