# PowerShell script to run basic example
Write-Host "Running basic example with multiple parameters..."
Write-Host ""

# Run the basic example with A, B, C, and SPEED parameters
$command = ".\qval.exe --config config\example\basic\basic.yaml --samples 1000"
Invoke-Expression $command

Write-Host ""
Write-Host "Done. Output written to: bin\output\example\basic\"
Write-Host "Kernel saved under:      bin\output\example\basic\code\eval.cl"
