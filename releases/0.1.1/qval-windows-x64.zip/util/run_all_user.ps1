# PowerShell script to run all user configurations
Write-Host "Running all USER configurations..."
Write-Host "================================="
Write-Host ""

$count = 0
$passed = 0
$failed = 0

$configFiles = Get-ChildItem -Path "config\user" -Recurse -Filter "*.yaml"

foreach ($file in $configFiles) {
    $count++
    Write-Host "Testing $($count): $($file.Name) ..."
    
    $command = ".\qval.exe --config `"$($file.FullName)`" --samples 1000"
    Invoke-Expression $command
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "FAILED (Exit code: $LASTEXITCODE)"
        $failed++
    } else {
        Write-Host "PASSED"
        $passed++
    }
    Write-Host ""
}

Write-Host ""
Write-Host "=================================================="
Write-Host "USER TESTS RESULTS:"
Write-Host "Total configs tested: $count"
Write-Host "Passed: $passed"
Write-Host "Failed: $failed"

if ($failed -eq 0) {
    Write-Host "ALL USER TESTS PASSED!"
} else {
    Write-Host "Some user tests failed."
}
Write-Host ""
