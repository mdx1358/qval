# PowerShell script to run all test configurations
Write-Host "Running all TEST configurations..."
Write-Host "================================="
Write-Host ""

$count = 0
$passed = 0
$failed = 0

$configFiles = Get-ChildItem -Path "config\test" -Recurse -Filter "*.yaml"

foreach ($file in $configFiles) {
    $count++
    Write-Host "Testing $($count): $($file.Name) ..."
    
    $command = ".\qval.exe -cf `"$($file.FullName)`" --report"
    Invoke-Expression $command
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "FAILED (Exit code: $LASTEXITCODE)"
        $failed++
    } else {
        Write-Host "PASSED"
        $passed++
    }
    Write-Host ""
}

Write-Host ""
Write-Host "=================================================="
Write-Host "TEST RESULTS:"
Write-Host "Total configs tested: $count"
Write-Host "Passed: $passed"
Write-Host "Failed: $failed"

if ($failed -eq 0) {
    Write-Host "ALL TESTS PASSED!"
} else {
    Write-Host "Some tests failed."
}
Write-Host ""
