# PowerShell script to run all slow test configurations
Write-Host "Running all SLOW TEST configurations..."
Write-Host "======================================"
Write-Host "WARNING: These tests may take a long time to complete!"
Write-Host ""

$count = 0
$passed = 0
$failed = 0

$configFiles = Get-ChildItem -Path "config\test_slow" -Recurse -Filter "*.yaml"

foreach ($file in $configFiles) {
    $count++
    Write-Host "Testing $($count): $($file.Name) ..."
    
    $command = ".\qval.exe --config `"$($file.FullName)`" --samples 1000"
    Invoke-Expression $command
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "FAILED (Exit code: $LASTEXITCODE)"
        $failed++
    } else {
        Write-Host "PASSED"
        $passed++
    }
    Write-Host ""
}

Write-Host ""
Write-Host "=================================================="
Write-Host "SLOW TEST RESULTS:"
Write-Host "Total configs tested: $count"
Write-Host "Passed: $passed"
Write-Host "Failed: $failed"

if ($failed -eq 0) {
    Write-Host "ALL SLOW TESTS PASSED!"
} else {
    Write-Host "Some slow tests failed."
}
Write-Host ""
