# PowerShell script to remove log files from output directory
Write-Host "Cleaning up log files from output directory..."
Write-Host ""

# Get all log files
$logFiles = Get-ChildItem -Path "output" -Recurse -Filter "*.log"

if ($logFiles.Count -eq 0) {
    Write-Host "No log files found in output directory." -ForegroundColor Green
    exit 0
}

# Show what will be removed
Write-Host "Found $($logFiles.Count) log files:" -ForegroundColor Yellow
$totalSize = 0
foreach ($file in $logFiles) {
    $sizeMB = [math]::Round($file.Length/1MB,2)
    $totalSize += $file.Length
    Write-Host "  $($file.FullName) - $sizeMB MB" -ForegroundColor Red
}

$totalSizeMB = [math]::Round($totalSize/1MB,2)
Write-Host ""
Write-Host "Total size to be freed: $totalSizeMB MB" -ForegroundColor Yellow
Write-Host ""

# Ask for confirmation
$response = Read-Host "Do you want to remove these log files? (y/N)"
if ($response -eq "y" -or $response -eq "Y") {
    Write-Host "Removing log files..." -ForegroundColor Yellow
    $logFiles | Remove-Item -Force
    Write-Host "Log files removed successfully!" -ForegroundColor Green
    Write-Host "Freed $totalSizeMB MB of disk space." -ForegroundColor Green
} else {
    Write-Host "Operation cancelled." -ForegroundColor Yellow
}
