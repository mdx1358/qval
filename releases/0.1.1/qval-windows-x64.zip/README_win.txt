QVAL Quick Start - Windows
==========================

What it is:
- QVAL is a GPU-accelerated function evaluator and optimizer.
  It runs thousands to millions of parameter variants in parallel on the GPU and writes results
  and reports. You can provide a simple math expression (expr) or, for advanced cases, a C-like
  expression file (OpenCL code) via expr_file. Prefer a GPU device when available.

Prerequisites:
- Windows 10/11 with a supported OpenCL runtime/driver
- Unzip the distribution. The `qval.exe` binary and example scripts are in the root directory.

Quick Start:
============

1. List GPU devices:
   .\qval.exe --list-devices

2. Run a basic example:
   .\qval.exe --config config\example\basic\basic.yaml

3. Run the tutorial:
   .\qval.exe --config config\tutorial\00_minimal\00_minimal.yaml

4. Run all tests:
   .\util\run_all_test.bat

5. Run GPU verification:
   .\run_gpu_verification.bat

Quick Sanity Checks:
====================

From the root directory, double-click:
- `run_basic_example.bat` - Basic example with multiple parameters (A, B, C, SPEED)
- `run_gpu_verification.bat` - Comprehensive GPU verification

Comprehensive Testing:
======================

From `util\`, double-click:
- `run_all_example.bat` - All example configurations
- `run_all_tutorial.bat` - All tutorial configurations
- `run_all_test.bat` - All test configurations (fast)
- `run_all_slow_test.bat` - All slow/GPU load tests
- `run_all_user.bat` - All user configurations
- `run_gpu_verification.bat` - Comprehensive GPU verification

Manual Commands:
===============

Command Prompt (recommended):
```cmd
# Basic example
.\qval.exe --config config\example\basic\basic.yaml --samples 1000

# Tutorial example
.\qval.exe --config config\tutorial\00_minimal\00_minimal.yaml --samples 1000

# Run with specific device
.\qval.exe --config config\example\basic\basic.yaml --device 0:0

# Generate reports
.\qval.exe --config config\tutorial\00_minimal\00_minimal.yaml --report txt,md,html --report-out .\report
```

Command Prompt (cmd):
```cmd
# Basic example
qval.exe --config config\example\basic\basic.yaml --samples 1000

# Tutorial example  
qval.exe --config config\tutorial\00_minimal\00_minimal.yaml --samples 1000
```

Where Output Goes:
=================
- output\<config_path>\code\eval.cl — generated OpenCL kernel
- output\<config_path>\<config_name>.csv — results CSV
- output\<config_path>\<config_name>.xlsx — results Excel (if configured)
- report\<config_path>\report.{txt,md,html,json} — human-readable reports

Configuration Structure:
========================
- config\example\ — Example configurations for different use cases
- config\tutorial\ — Step-by-step tutorial configurations
- config\test\ — Test configurations (fast execution)
- config\test_slow\ — Slow/GPU load test configurations
- config\user\ — User-defined configurations (create your own here)

Documentation:
==============
- doc\qval_manual.txt — Complete user manual in text format

Notes:
======
- Use PowerShell for best experience (colored output, better error handling)
- CSV/XLSX output paths are configured in each YAML file
- Use --quiet to reduce console output, --verbose for OpenCL details
- GPU acceleration is automatic when available
- See doc\qval_manual.txt for complete user manual

Troubleshooting:
===============
- If GPU not detected: Check OpenCL drivers are installed
- If permission denied: Run Command Prompt as Administrator
- If paths not found: Ensure you're running from the root directory
- If batch files fail: Check that qval.exe is in the same directory
- For detailed help: .\qval.exe --help

Notes:
======
- All scripts are pure batch files - no PowerShell required
- Works on any Windows system (Windows 7, 8, 10, 11)
- No execution policy issues or security restrictions
- Double-click any .bat file to run
