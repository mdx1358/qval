# PowerShell script to run comprehensive GPU verification tests
Write-Host "Running comprehensive GPU verification tests..."
Write-Host "This will test if the GPU is actually working correctly."
Write-Host ""

# Test 1: Comprehensive GPU test
Write-Host "Test 1: Comprehensive GPU verification (50K samples)"
Write-Host "Testing multiple parameter types and distributions..."
$command1 = ".\qval.exe --config config\test\gpu_verification\comprehensive_gpu_test.yaml"
Invoke-Expression $command1

if ($LASTEXITCODE -ne 0) {
    Write-Host "GPU verification test FAILED"
    exit 1
}
Write-Host "Comprehensive GPU test PASSED"
Write-Host ""

# Test 2: GPU stress test
Write-Host "Test 2: GPU stress test (100K samples)"
Write-Host "Testing high sample count and complex math operations..."
$command2 = ".\qval.exe --config config\test\gpu_verification\gpu_stress_test.yaml"
Invoke-Expression $command2

if ($LASTEXITCODE -ne 0) {
    Write-Host "GPU stress test FAILED"
    exit 1
}
Write-Host "GPU stress test PASSED"
Write-Host ""

Write-Host "GPU verification summary:"
Write-Host "- Comprehensive test: Multiple parameter types and distributions"
Write-Host "- Stress test: High sample count and complex operations"
Write-Host "- All tests completed successfully"
Write-Host ""
Write-Host "Your GPU is working correctly with QVAL!"
