#!/usr/bin/env bash
set -euo pipefail

echo "Running basic example with multiple parameters..."
echo ""

# Run the basic example with A, B, C, and SPEED parameters
./qval --config config/example/basic/basic.yaml --samples 1000

echo ""
echo "Done. Output written to: bin/output/example/basic/"
echo "Kernel saved under:      bin/output/example/basic/code/eval.cl"

