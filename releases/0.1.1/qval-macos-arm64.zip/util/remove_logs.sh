#!/bin/bash
# Shell script to remove log files from output directory

echo "Cleaning up log files from output directory..."
echo ""

# Get all log files
log_files=$(find output -name "*.log" -type f)

if [ -z "$log_files" ]; then
    echo "No log files found in output directory."
    exit 0
fi

# Count files and calculate total size
file_count=$(echo "$log_files" | wc -l)
total_size=0

echo "Found $file_count log files:"
while IFS= read -r file; do
    if [ -f "$file" ]; then
        size_bytes=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
        size_mb=$(echo "scale=2; $size_bytes / 1024 / 1024" | bc)
        total_size=$((total_size + size_bytes))
        echo "  $file - ${size_mb} MB"
    fi
done <<< "$log_files"

total_size_mb=$(echo "scale=2; $total_size / 1024 / 1024" | bc)
echo ""
echo "Total size to be freed: ${total_size_mb} MB"
echo ""

# Ask for confirmation
read -p "Do you want to remove these log files? (y/N): " response
if [ "$response" = "y" ] || [ "$response" = "Y" ]; then
    echo "Removing log files..."
    echo "$log_files" | xargs rm -f
    echo "Log files removed successfully!"
    echo "Freed ${total_size_mb} MB of disk space."
else
    echo "Operation cancelled."
fi
