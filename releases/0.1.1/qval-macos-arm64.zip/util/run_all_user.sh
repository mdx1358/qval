#!/bin/bash

# Run all user configurations
echo "Running all USER configurations..."
echo "================================="

# Find all user configs
configs=$(find config/user -name "*.yaml" 2>/dev/null | sort)
total=$(echo "$configs" | wc -l | tr -d ' ')

if [ $total -eq 0 ]; then
    echo "No user configurations found in bin/config/user/"
    echo "Create user configurations in bin/config/user/ to use this script."
    exit 0
fi

passed=0
failed=0

echo "Total user configs: $total"
echo "=================================================="

i=1
for config in $configs; do
    config_name=$(basename "$config")
    config_dir=$(dirname "$config")
    dir_name=$(basename "$config_dir")
    
    echo -n "Testing ($i/$total): $dir_name/$config_name ... "
    
    # Run with standard samples for user configs
    ./qval --config "$config" --samples 1000 > /tmp/user_test.log 2>&1
    exit_code=$?
    
    # Check for verification results
    if grep -q "VERIFY_PASS" /tmp/user_test.log; then
        echo "PASSED (Verification OK)"
        passed=$((passed + 1))
    elif [ $exit_code -eq 0 ]; then
        echo "PASSED"
        passed=$((passed + 1))
    else
        echo "FAILED (Exit code: $exit_code)"
        failed=$((failed + 1))
    fi
    
    i=$((i + 1))
done

echo "=================================================="
echo "USER TEST RESULTS:"
echo "Total configs tested: $total"
echo "Passed: $passed"
echo "Failed: $failed"

if [ $failed -eq 0 ]; then
    echo "ALL USER TESTS PASSED!"
else
    echo "Some user tests failed."
fi

# Clean up
rm -f /tmp/user_test.log

