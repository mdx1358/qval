# QVAL Tutorial

This tutorial lives under bin/config/tutorial and walks through the system from the simplest config to more advanced features.

Folder structure
- Each example lives in its own folder and contains exactly one YAML config plus any resources (expr files, CSVs):
  - 00_minimal/00_minimal.yaml
  - 01_expr_file/01_expr_file.yaml (and expr/score.txt)
  - 02_csv_by_index/02_csv_by_index.yaml (and data/values.csv)
  - 03_csv_by_name/03_csv_by_name.yaml (and data/values.csv)
  - 04_categorical_enum/04_categorical_enum.yaml
  - 05_md_tensor/05_md_tensor.yaml
  - 06_sampler_lhs/06_sampler_lhs.yaml
  - 07_verify_outputs/07_verify_outputs.yaml
  - 08_cem_optimize/08_cem_optimize.yaml
  - 09_de_optimize/09_de_optimize.yaml
- A lay-people examples set is under tutorial/lay_people with finance-oriented tasks.

How to run examples
- Basic single run (example: minimal):
  qval -cf bin/config/tutorial/00_minimal/00_minimal.yaml
- With performance summaries to stdout and saved artifacts:
  qval -cf bin/config/tutorial/00_minimal/00_minimal.yaml --perf --perf-yaml bin/results/perf/tutorial_minimal.yaml --perf-txt bin/results/perf/tutorial_minimal.txt
- You can view outputs under bin/results/...

Index of examples
1) 00_minimal
   - Smallest useful config: 1 scalar parameter sampled uniformly, simple expression, CSV output.
2) 01_expr_file (+ expr/score.txt)
   - Put your expression in a file; parameters X and Y sampled.
3) 02_csv_by_index (+ data/values.csv)
   - Provide parameter values from a CSV by column index.
4) 03_csv_by_name (+ data/values.csv)
   - Provide parameter values from a CSV by column name.
5) 04_categorical_enum
   - Use categorical integer parameter with enum labels.
6) 05_md_tensor
   - Multi-dimensional parameter (tensor) and reductions A_sum/A_mean in expressions.
7) 06_sampler_lhs
   - Switch the sampler to LHS for better space-filling on uniform scalars.
8) 07_verify_outputs
   - Use verify.top_score and require CSV/XLSX outputs.
9) 08_cem_optimize
   - Run Cross-Entropy Method (CEM) to minimize a function (Rosenbrock).
10) 09_de_optimize
   - Use Differential Evolution (DE) to minimize a function (Rosenbrock).

Lay-people examples (tutorial/lay_people)
- 01_savings_growth/config.yaml
  - Calculate future value of periodic contributions; vary contribution and interest rate to maximize final value.
- 02_loan_payment_fit/config.yaml
  - Given principal, term, and a target payment, discover an interest rate that matches the payment (minimize error).
- 03_fund_pick_from_csv/config.yaml (and data/returns.csv)
  - Pick the best fund from a CSV of annual returns (maximize return).

About A_sum, A_mean, and A_min
- When a parameter has shape (e.g., A with shape [m,n]), the system defines the following helpers for that parameter name:
  - A_sum(): sums all elements of A.
  - A_mean(): averages all elements of A.
- There are no built-in A_min() or A_max() reductions at this time. For scalar min/max logic in expressions, use fmin()/fmax() as needed.

Notes
- Expressions: You can use common math functions (sin, cos, pow, fabs, fmin/fmax) as well as tensor helpers like A_sum() and A_mean() when a parameter has shape.
- Samplers: Set fnev.sampler: rng (default), lhs, halton, or sobol (1D support for halton/sobol here).
- Performance: Use --perf to print PERF lines; --perf-yaml/--perf-txt to save them.
- Precision: Use --precision {float|half|double}; by default unsupported precisions fall back to float32. Add --no-fallback to enforce strict precision and fail if unsupported.
  - Example: qval -cf bin/config/tutorial/00_minimal/00_minimal.yaml --precision double --no-fallback --perf
- Outputs: Set out_csv and (optionally) out_xlsx. Verify can enforce that outputs exist.
- Paths in these YAMLs are relative to the YAML file directory unless absolute.

