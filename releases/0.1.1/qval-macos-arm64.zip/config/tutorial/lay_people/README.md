# Lay-people examples

This set contains approachable scenarios using spreadsheet-like data and familiar formulas.

How to run
- Example (savings growth):
  qval -cf bin/config/tutorial/lay_people/01_savings_growth/config.yaml --perf

Examples
1) 01_savings_growth/config.yaml
   - Vary monthly contribution and annual interest rate to maximize the final value after N years.
2) 02_loan_payment_fit/config.yaml
   - Given principal and term, find an interest rate that matches a target payment (minimize absolute error).
3) 03_fund_pick_from_csv/config.yaml + data/returns.csv
   - Choose the best mutual fund based on historical annual returns from a CSV.

