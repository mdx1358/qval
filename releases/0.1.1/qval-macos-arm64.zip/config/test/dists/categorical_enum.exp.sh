#!/usr/bin/env bash
# Expectation: CSV contains quoted label "fast" in the SPEED column
CSV="$1"
LOG="$2"
# find SPEED column index from header
hdr=$(head -n1 "$CSV")
idx=$(awk -F, -v h="$hdr" 'BEGIN{n=split(h,a,","); for(i=1;i<=n;i++){if(a[i]=="SPEED"){print i; exit}} exit 1}') || exit 1
# get first data row field
val=$(awk -F, -v k="$idx" 'NR==2{print $k}' "$CSV")
if [[ "$val" == '"fast"' || "$val" == fast ]]; then exit 0; else exit 1; fi

