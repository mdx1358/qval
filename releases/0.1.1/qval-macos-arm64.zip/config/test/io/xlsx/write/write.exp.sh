#!/usr/bin/env bash
# Expectation: out_xlsx file exists; parse from log or fallback to known path
CSV="$1"
LOG="$2"
# try to parse path from log
xlsx=$(grep -Eo 'wrote XLSX: .+' "$LOG" | sed -E 's/.*wrote XLSX: (.*)/\1/')
if [[ -z "$xlsx" ]]; then
  xlsx="/Users/mdx/dev/prj/DEV/QVAL/bin/results/test_xlsx_write.xlsx"
fi
[[ -f "$xlsx" ]]

